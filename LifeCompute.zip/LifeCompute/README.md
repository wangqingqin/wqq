# LifeCompute
 Cellular automaton sample
 
cell
  status
  env.
update
	update data 
	update graph
timer
	execute 
init
	initialize 
GUI
	ui
